# <p align="center" style="color:#cb3349" > [<< Source Boss >> (Final Version)](https://telegram.me/TH3BS)

<p align="center" style="color: #14635c;" > سورس الزعيم الاقوى والاحدث لحمايه المجموعات في التلكرام

***

# <p align="center" style="color: #14635c;" > [التنصيب بكود واحد](https://t.me/TH3BS/4121)
```sh
git clone https://github.com/TH3BS/BOSS.git ;cd BOSS;chmod +x ins;./ins
```
```
» فقط أضغط على الكود ☝️ وقم بنسخه
» ثم الصقه بالترمنال وانتر تتنظر يتنصب 
» بعدهہ‌‏آ يطـلب مـعلومـآت بآلترمـنآل .
» تدخل مـعلومـآتگ مـن توگن ومـعرفگ 
» وسـوف يعمـل آلبوت بالسـگرين تلقآئيآ ...
```
# <p align="center" style="color: #14635c;" > [كود الرون](https://t.me/TH3BS/5399)
```sh
./UserBot/run

Example

./@MaaBot/run
```
# <p align="center" style="color: #14635c;" >  [لتغيير المطور الاساسي ](https://t.me/SourceBoss/37)
```sh
ارسل للبوت : نقل ملكيه البوت
```
[MoHaMMeD](https://t.me/vvsvv)

[Source developer](https://t.me/th3boss)

[Channel explanation](https://t.me/SourceBoss)
